import display from "./display";

// place your code on line 5 above the export statement below

class Snake {
  public currentPosition: number;
  public currentDirection: number;
  constructor() {
    this.currentPosition = 0;
    this.currentDirection = 0;
  }

  public set move(currentPosition: number) {
    if (currentPosition > 0) {
      this.currentPosition + 1;
    } else {
      this.currentPosition - 1;
    }
  }

  public set turn(currentDirection: number) {
    if ((currentDirection = -1)) {
      this.currentDirection = 1;
    } else {
      this.currentDirection = -1;
    }
  }

  public get position() {
    return this.currentPosition;
  }
}

export default Snake;
